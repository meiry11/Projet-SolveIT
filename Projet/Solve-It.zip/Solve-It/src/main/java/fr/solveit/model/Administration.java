package fr.solveit.model;

public class Administration {
}
