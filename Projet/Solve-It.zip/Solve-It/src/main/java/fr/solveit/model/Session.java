package fr.solveit.model;

public class Session {
}
