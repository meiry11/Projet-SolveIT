package fr.solveit.model;

public class Ville {
}
