package fr.solveit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SolveItApplicationTests {

	@Test
	void contextLoads() {
	}

}
