package aston.springini.entity;

import jakarta.persistence.Entity;

/**
 * Interface des instruments
 * @author roumaissa
 */
public interface Instrument {

}
