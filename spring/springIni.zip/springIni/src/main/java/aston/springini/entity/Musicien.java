package aston.springini.entity;

/**
 * Interface des Musicien
 * @author roumaissa
 */
public interface Musicien {
    public void jouer();
}
